<?php
define('ROOT_PART', Root_part());
define('APIKEY', 'AIzaSyAiWoHNeDOg9wfPn20ZqoFcYdSRMNZXHbg');
define('GJ_CODE', 'VN');
define('SITE_NAME', 'LeoCloud YT');
define('TITLENAME', 'LeoCloud YT');
define('EN2DEKEY', 'Z!-j^TN|WJ-+EXB|G-8V3dP+r*<OAjB07zBD@VAbk?@(oT%)D+.^RqbA@O|(Tn#');
define('EMAIL', 'admin@leocloud.uk');
?>